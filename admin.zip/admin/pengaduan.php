<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';

/* =====================================================
   PROSES UBAH STATUS PENGADUAN
   ===================================================== */
if (isset($_POST['ubah_status'])) {
  $id_pengaduan = intval($_POST['id_pengaduan']);
  $status       = mysqli_real_escape_string($conn, $_POST['status']);
  $allowed      = ['Menunggu', 'Diproses', 'Selesai'];

  if (in_array($status, $allowed)) {
    $sukses = mysqli_query($conn, "UPDATE pengaduan SET status='$status' WHERE id_pengaduan=$id_pengaduan");
    $_SESSION['flash'] = [
      'tipe'  => $sukses ? 'success' : 'danger',
      'pesan' => $sukses ? 'Status pengaduan berhasil diperbarui!' : 'Gagal memperbarui status.'
    ];
  } else {
    $_SESSION['flash'] = ['tipe' => 'danger', 'pesan' => 'Status tidak valid.'];
  }
  header('Location: pengaduan.php');
  exit;
}

include 'partials/sidebar.php';

/* =====================================================
   AMBIL DATA PENGADUAN
   ===================================================== */
$query = mysqli_query($conn, "
  SELECT p.*, u.nama AS nama_pelapor, k.nama_kategori, d.nama_dusun
  FROM pengaduan p
  JOIN users u ON p.nik = u.nik
  JOIN kategori k ON p.kategori_id = k.id_kategori
  JOIN dusun d ON p.dusun_id = d.id_dusun
  ORDER BY p.tanggal DESC
");
?>

<div class="pagetitle">
  <h1>Manajemen Pengaduan</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item active">Pengaduan</li>
    </ol>
  </nav>
</div>

<?php if (isset($_SESSION['flash'])): ?>
  <div class="alert alert-<?= $_SESSION['flash']['tipe'] ?> alert-dismissible fade show" role="alert">
    <?= $_SESSION['flash']['pesan'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php unset($_SESSION['flash']); ?>
<?php endif; ?>

<section class="section">
  <div class="card">
    <div class="card-body pt-3">
      <h5 class="card-title">Data Pengaduan Masyarakat</h5>
      <div class="table-responsive">
        <table id="tabelLaporan" class="table align-middle">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Pelapor</th>
              <th>Dusun</th>
              <th>Kategori</th>
              <th>Isi Pengaduan</th>
              <th>Tanggal</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $no = 1; $modals = ""; while ($row = mysqli_fetch_assoc($query)): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_pelapor']) ?></td>
                <td><?= $row['nama_dusun'] ?></td>
                <td><?= $row['nama_kategori'] ?></td>
                <td><?= htmlspecialchars(substr($row['isi_pengaduan'], 0, 40)) ?>...</td>
                <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
                <td>
                  <span class="badge bg-<?= $row['status'] == 'Selesai' ? 'success' : ($row['status'] == 'Diproses' ? 'warning' : 'secondary') ?>">
                    <?= $row['status'] ?>
                  </span>
                </td>
                <td>
                  <!-- Tombol Detail -->
                  <button class="btn btn-info btn-sm mb-1" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id_pengaduan'] ?>">
                    Detail
                  </button>

                  <!-- Form Ubah Status -->
                  <form method="post" class="d-flex gap-1 mt-1">
                    <input type="hidden" name="id_pengaduan" value="<?= $row['id_pengaduan'] ?>">
                    <select name="status" class="form-select form-select-sm">
                      <?php foreach (['Menunggu', 'Diproses', 'Selesai'] as $s): ?>
                        <option value="<?= $s ?>" <?= $row['status'] == $s ? 'selected' : '' ?>><?= $s ?></option>
                      <?php endforeach; ?>
                    </select>
                    <button type="submit" name="ubah_status" class="btn btn-primary btn-sm">Simpan</button>
                  </form>
                </td>
              </tr>

              <?php /* =====================================================
                 RAKIT MODAL DETAIL (disimpan dalam variabel $modals)
                 ===================================================== */
                ob_start();
                // 1. tentukan preview lampiran bila ada
                $previewLampiran = '';
                if ($row['lampiran']) {
                  $ext = strtolower(pathinfo($row['lampiran'], PATHINFO_EXTENSION));
                  $fileUrl = "../pelapor/uploads/lampiran/{$row['lampiran']}";
                  if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                    $previewLampiran = "<img src='{$fileUrl}' alt='Lampiran' class='img-fluid rounded border'/>";
                  } elseif ($ext === 'pdf') {
                    $previewLampiran = "<embed src='{$fileUrl}' type='application/pdf' width='100%' height='500px' class='border rounded' />";
                  } else {
                    $previewLampiran = "<a href='{$fileUrl}' target='_blank'>Unduh Lampiran</a>";
                  }
                }
              ?>
                <div class="modal fade" id="modalDetail<?= $row['id_pengaduan'] ?>" tabindex="-1" aria-labelledby="labelDetail<?= $row['id_pengaduan'] ?>" aria-hidden="true">
                  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="labelDetail<?= $row['id_pengaduan'] ?>">Detail Pengaduan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <div class="row g-4">
                          <div class="col-lg-6">
                            <table class="table table-borderless mb-0">
                              <tr><th width="150">Nama Pelapor</th><td><?= htmlspecialchars($row['nama_pelapor']) ?></td></tr>
                              <tr><th>Dusun</th><td><?= $row['nama_dusun'] ?></td></tr>
                              <tr><th>Kategori</th><td><?= $row['nama_kategori'] ?></td></tr>
                              <tr><th>Tanggal</th><td><?= date('d/m/Y H:i', strtotime($row['tanggal'])) ?></td></tr>
                              <tr><th>Status</th><td><?= $row['status'] ?></td></tr>
                              <tr><th>Isi Pengaduan</th><td><?= nl2br(htmlspecialchars($row['isi_pengaduan'])) ?></td></tr>
                            </table>
                          </div>
                          <div class="col-lg-6">
                            <?php if ($previewLampiran): ?>
                              <h6 class="fw-bold mb-2">Lampiran</h6>
                              <?= $previewLampiran ?>
                            <?php else: ?>
                              <p class="text-muted">Tidak ada lampiran.</p>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              <?php $modals .= ob_get_clean(); ?>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<!-- ===== CETAK SEMUA MODAL DI SINI (di luar tbody) ===== -->
<?= $modals ?>

<?php include 'partials/footer.php'; ?>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const customTable = document.querySelector("#tabelLaporan");
  if (customTable) {
    new simpleDatatables.DataTable(customTable, {
      labels: {
        placeholder: "Cari...",
        perPage: "entri per halaman",
        noRows: "Tidak ada data ditemukan",
        info: "Menampilkan {start} - {end} dari total {rows} entri"
      },
      layout: {
        top: "{select}",
        bottom: "{info}{pager}"
      },
      columnDefs: [
        { orderable: false, targets: [7] }
      ]
    });
  }
});
</script>