<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
include 'partials/sidebar.php';

// Ambil data jumlah pengaduan per cluster
$data = [];
$query = mysqli_query($conn, "
  SELECT cluster_ke, COUNT(*) as total 
  FROM hasil_cluster 
  GROUP BY cluster_ke 
  ORDER BY cluster_ke ASC
");
while ($row = mysqli_fetch_assoc($query)) {
  $data[] = [
    'cluster' => 'Cluster ' . $row['cluster_ke'],
    'total'   => $row['total']
  ];
}
?>

<div class="pagetitle">
  <h1>Grafik Clustering</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item"><a href="cluster.php">Cluster</a></li>
      <li class="breadcrumb-item active">Grafik</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">
  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Jumlah Pengaduan per Cluster</h5>
      <div id="chartCluster" style="min-height: 350px;"></div>
    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    const options = {
      series: [{
        name: 'Total Pengaduan',
        data: <?= json_encode(array_column($data, 'total')) ?>
      }],
      chart: {
        type: 'bar',
        height: 350
      },
      xaxis: {
        categories: <?= json_encode(array_column($data, 'cluster')) ?>
      }
    };

    new ApexCharts(document.querySelector("#chartCluster"), options).render();
  });
</script>