<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
include 'partials/sidebar.php';

/* ── Filter tanggal ───────────────────────────────────────── */
$where = "";
if (!empty($_GET['dari']) && !empty($_GET['sampai'])) {
  $dari   = $_GET['dari'];
  $sampai = $_GET['sampai'];
  $where  = "WHERE p.tanggal BETWEEN '$dari' AND '$sampai'";
} else {
  $dari = $sampai = '';
}

/* ── Data laporan (JOIN users untuk nama) ────────────────── */
$sql = "
  SELECT p.*, u.nama AS nama_pelapor, k.nama_kategori, d.nama_dusun
  FROM pengaduan p
  JOIN users    u ON p.nik = u.nik       /* ambil nama pelapor */
  JOIN kategori k ON p.kategori_id = k.id_kategori
  JOIN dusun    d ON p.dusun_id   = d.id_dusun
  $where
  ORDER BY p.tanggal DESC
";
$query = mysqli_query($conn, $sql);
?>

<!-- ======== HTML ======== -->
<div class="pagetitle">
  <h1>Laporan Pengaduan</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item active">Laporan</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="card">
    <div class="card-body pt-3">
      <!-- ==== Filter ==== -->
      <h5 class="card-title">Filter Laporan</h5>
      <form method="GET" class="row g-3 mb-4">
        <div class="col-md-4">
          <label class="form-label">Dari Tanggal</label>
          <input type="date" name="dari" value="<?= $dari ?>" class="form-control">
        </div>
        <div class="col-md-4">
          <label class="form-label">Sampai Tanggal</label>
          <input type="date" name="sampai" value="<?= $sampai ?>" class="form-control">
        </div>
        <div class="col-md-4 d-flex align-items-end">
          <button class="btn btn-primary me-2" type="submit">Filter</button>
          <a href="laporan.php" class="btn btn-secondary me-2">Reset</a>
          <!-- Tombol Export PDF -->
          <a href="export_laporan.php?dari=<?= $dari ?>&sampai=<?= $sampai ?>" class="btn btn-danger" target="_blank">
            Export PDF
          </a>
        </div>
      </form>

      <!-- ==== Tabel Laporan ==== -->
      <div class="table-responsive">
        <table id="tabelLaporan" class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Pelapor</th>
              <th>Dusun</th>
              <th>Kategori</th>
              <th>Isi</th>
              <th>Tanggal</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): ?>
            <tr>
              <td><?= $no++ ?></td>
              <!-- gunakan nama_pelapor -->
              <td><?= htmlspecialchars($row['nama_pelapor']) ?></td>
              <td><?= $row['nama_dusun'] ?></td>
              <td><?= $row['nama_kategori'] ?></td>
              <td><?= htmlspecialchars($row['isi_pengaduan']) ?></td>
              <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
              <td>
                <span class="badge bg-<?= $row['status']=='Selesai'?'success':($row['status']=='Diproses'?'warning':'secondary') ?>">
                  <?= $row['status'] ?>
                </span>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>

<!-- Datatable -->
<script>
document.addEventListener("DOMContentLoaded", () => {
  const tbl = document.querySelector("#tabelLaporan");
  if (tbl) {
    new simpleDatatables.DataTable(tbl, {
      labels: {
        placeholder: "Cari...",
        perPage: "entri per halaman",
        noRows: "Tidak ada data ditemukan",
        info: "Menampilkan {start} - {end} dari total {rows} entri"
      },
      layout: { top: "{select}", bottom: "{info}{pager}" }
    });
  }
});
</script>
