<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
?>

<?php include 'partials/sidebar.php'; ?>

<?php
// Statistik
$total_pengaduan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM pengaduan"))['total'];
$total_diproses = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM pengaduan WHERE status='Diproses'"))['total'];
$total_selesai = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM pengaduan WHERE status='Selesai'"))['total'];

// Grafik per kategori
$kategori_query = mysqli_query($conn, "
  SELECT k.nama_kategori, COUNT(*) as jumlah 
  FROM pengaduan p
  JOIN kategori k ON p.kategori_id = k.id_kategori
  GROUP BY k.id_kategori
");
$kategori_data = [];
while ($row = mysqli_fetch_assoc($kategori_query)) {
  $kategori_data[] = $row;
}

// Grafik per dusun
$dusun_query = mysqli_query($conn, "
  SELECT d.nama_dusun, COUNT(*) as jumlah 
  FROM pengaduan p
  JOIN dusun d ON p.dusun_id = d.id_dusun
  GROUP BY d.id_dusun
");
$dusun_data = [];
while ($row = mysqli_fetch_assoc($dusun_query)) {
  $dusun_data[] = $row;
}
?>

<div class="pagetitle">
  <h1>Dashboard</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Dashboard</li>
    </ol>
  </nav>
</div>

<section class="section dashboard">
  <div class="row">

    <!-- Kartu Total Pengaduan -->
    <div class="col-lg-4 col-md-6">
      <div class="card info-card">
        <div class="card-body">
          <h5 class="card-title">Total Pengaduan</h5>
          <h6><?= $total_pengaduan ?></h6>
        </div>
      </div>
    </div>

    <!-- Kartu Diproses -->
    <div class="col-lg-4 col-md-6">
      <div class="card info-card">
        <div class="card-body">
          <h5 class="card-title">Diproses</h5>
          <h6><?= $total_diproses ?></h6>
        </div>
      </div>
    </div>

    <!-- Kartu Selesai -->
    <div class="col-lg-4 col-md-6">
      <div class="card info-card">
        <div class="card-body">
          <h5 class="card-title">Selesai</h5>
          <h6><?= $total_selesai ?></h6>
        </div>
      </div>
    </div>

    <!-- Grafik Kategori -->
    <div class="col-lg-6">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Pengaduan per Kategori</h5>
          <div id="chartKategori" style="min-height: 350px;"></div>
        </div>
      </div>
    </div>

    <!-- Grafik Dusun -->
    <div class="col-lg-6">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Pengaduan per Dusun</h5>
          <div id="chartDusun" style="min-height: 350px;"></div>
        </div>
      </div>
    </div>

  </div>
</section>

<?php include 'partials/footer.php'; ?>

<script>
  document.addEventListener("DOMContentLoaded", () => {
    // Pie Chart Kategori
    new ApexCharts(document.querySelector("#chartKategori"), {
      chart: {
        type: 'pie',
        height: 350
      },
      labels: <?= json_encode(array_column($kategori_data, 'nama_kategori')) ?>,
      series: <?= json_encode(array_column($kategori_data, 'jumlah')) ?>
    }).render();

    // Bar Chart Dusun
    new ApexCharts(document.querySelector("#chartDusun"), {
      chart: {
        type: 'bar',
        height: 275
      },
      series: [{
        name: 'Jumlah',
        data: <?= json_encode(array_column($dusun_data, 'jumlah')) ?>
      }],
      xaxis: {
        categories: <?= json_encode(array_column($dusun_data, 'nama_dusun')) ?>
      }
    }).render();
  });
</script>
