<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
include 'partials/sidebar.php';

// Tambah kategori
if (isset($_POST['tambah'])) {
  $nama = $_POST['nama_kategori'];
  $stmt = $conn->prepare("INSERT INTO kategori (nama_kategori) VALUES (?)");
  $stmt->bind_param("s", $nama);
  $stmt->execute();
  header("Location: kategori.php");
}

// Edit kategori
if (isset($_POST['edit'])) {
  $id = $_POST['id_kategori'];
  $nama = $_POST['nama_kategori'];
  $stmt = $conn->prepare("UPDATE kategori SET nama_kategori=? WHERE id_kategori=?");
  $stmt->bind_param("si", $nama, $id);
  $stmt->execute();
  header("Location: kategori.php");
}

// Hapus kategori
if (isset($_GET['hapus'])) {
  $id = $_GET['hapus'];
  $conn->query("DELETE FROM kategori WHERE id_kategori=$id");
  header("Location: kategori.php");
}

// Ambil data kategori
$query = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id_kategori ASC");
?>

<div class="pagetitle">
  <h1>Data Kategori</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item active">Kategori</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="card">
    <div class="card-body pt-3">
      <h5 class="card-title">Daftar Kategori Pengaduan</h5>

      <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalTambah">Tambah Kategori</button>

      <div class="table-responsive">
        <table id="tabelKategori" class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Kategori</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1; 
            $modals = '';
            while ($row = mysqli_fetch_assoc($query)) : ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                <td>
                  <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id_kategori'] ?>">Edit</button>
                  <a href="kategori.php?hapus=<?= $row['id_kategori'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
              </tr>
              <?php
              $modals .= '
              <div class="modal fade" id="modalEdit' . $row['id_kategori'] . '" tabindex="-1">
                <div class="modal-dialog">
                  <form method="post" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit Kategori</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                      <input type="hidden" name="id_kategori" value="' . $row['id_kategori'] . '">
                      <div class="mb-3">
                        <label class="form-label">Nama Kategori</label>
                        <input type="text" name="nama_kategori" class="form-control" value="' . htmlspecialchars($row['nama_kategori']) . '" required>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                    </div>
                  </form>
                </div>
              </div>';
              ?>
            <?php endwhile; ?>
          </tbody>
        </table>
        <?= $modals ?>
      </div>

    </div>
  </div>
</section>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Kategori</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Nama Kategori</label>
          <input type="text" name="nama_kategori" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah" class="btn btn-success">Tambah</button>
      </div>
    </form>
  </div>
</div>

<?php include 'partials/footer.php'; ?>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const tabel = document.querySelector("#tabelKategori");
  if (tabel) {
    new simpleDatatables.DataTable(tabel, {
      labels: {
        placeholder: "Cari...",
        perPage: "entri per halaman",
        noRows: "Tidak ada data ditemukan",
        info: "Menampilkan {start} - {end} dari total {rows} entri"
      },
      layout: {
        top: "{select}",
        bottom: "{info}{pager}"
      }
    });
  }
});
</script>
