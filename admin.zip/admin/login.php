<?php
session_start();
include '../config/koneksi.php';

// Cek jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Cek akun admin
  $query = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username'");
  $data = mysqli_fetch_assoc($query);

  if ($data && md5($password) === $data['password']) {
    $_SESSION['admin_id'] = $data['id_admin'];
    $_SESSION['admin_username'] = $data['username'];
    header("Location: index.php");
    exit;
  } else {
    $error = "Username atau password salah!";
  }
}
?>

<!-- HTML Template Login dari NiceAdmin -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Login - SIPEMAS</title>
  <link href="NiceAdmin/assets/img/logo1.png" rel="icon">
  <link href="NiceAdmin/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="NiceAdmin/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="NiceAdmin/assets/css/style.css" rel="stylesheet">
</head>

<body>

  <main>
    <div class="container">
      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="d-flex justify-content-center py-4">
                <a href="#" class="logo d-flex align-items-center w-auto">
                  <img src="NiceAdmin/assets/img/logo1.png" alt="">
                  <span class="d-none d-lg-block">SIPEMAS</span>
                </a>
              </div>

              <div class="card mb-3">
                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">Login Admin</h5>
                    <p class="text-center small">Masukkan username dan password</p>
                  </div>

                  <?php if (isset($error)) : ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                  <?php endif; ?>

                  <form class="row g-3 needs-validation" novalidate method="POST">

                    <div class="col-12">
                      <label for="yourUsername" class="form-label">Username</label>
                      <div class="input-group has-validation">
                        <span class="input-group-text" id="inputGroupPrepend">@</span>
                        <input type="text" name="username" class="form-control" id="yourUsername" required>
                        <div class="invalid-feedback">Masukkan username Anda.</div>
                      </div>
                    </div>

                    <div class="col-12">
                      <label for="yourPassword" class="form-label">Password</label>
                      <input type="password" name="password" class="form-control" id="yourPassword" required>
                      <div class="invalid-feedback">Masukkan password Anda.</div>
                    </div>

                    <div class="col-12">
                      <button class="btn btn-primary w-100" type="submit">Login</button>
                    </div>

                  </form>

                </div>
              </div>

              <div class="credits text-center">
                <small>© <?= date('Y') ?> SIPEMAS | by Genzuli</small>
              </div>

            </div>
          </div>
        </div>
      </section>
    </div>
  </main>

  <script src="NiceAdmin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="NiceAdmin/assets/js/main.js"></script>

</body>

</html>