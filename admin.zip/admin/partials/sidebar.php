<?php
if (!isset($_SESSION)) session_start();
$current = basename($_SERVER['PHP_SELF']);
$cluster_pages = ['cluster.php', 'grafik_cluster.php'];
$is_cluster_active = in_array($current, $cluster_pages);
?>
<?php include 'header.php' ?>
<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center">
  <div class="d-flex align-items-center justify-content-between">
    <a href="index.php" class="logo d-flex align-items-center">
      <img src="NiceAdmin/assets/img/logo1.png" alt="">
      <span class="d-none d-lg-block">SIPEMAS</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>
  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">
      <li class="nav-item dropdown pe-3">
        <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
          <span class="d-none d-md-block dropdown-toggle ps-2"><?= $_SESSION['admin_username'] ?? 'Admin'; ?></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
          <li><a class="dropdown-item d-flex align-items-center" href="#" id="logoutBtn">
  <i class="bi bi-box-arrow-right"></i><span>Logout</span>
</a>
          </li>
        </ul>
      </li>
    </ul>
  </nav>
</header><!-- End Header -->

<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
  <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
      <a class="nav-link <?= $current == 'index.php' ? '' : 'collapsed' ?>" href="index.php">
        <i class="bi bi-grid"></i><span>Dashboard</span>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link <?= $current == 'pengaduan.php' ? '' : 'collapsed' ?>" href="pengaduan.php">
        <i class="bi bi-chat-left-text"></i><span>Kelola Pengaduan</span>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link <?= $is_cluster_active ? '' : 'collapsed' ?>" data-bs-target="#cluster-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-diagram-3"></i><span>Cluster</span><i class="bi bi-chevron-down ms-auto"></i>
      </a>
      <ul id="cluster-nav" class="nav-content collapse <?= $is_cluster_active ? 'show' : '' ?>" data-bs-parent="#sidebar-nav">
        <li>
          <a href="cluster.php" class="<?= $current == 'cluster.php' ? 'active' : '' ?>">
            <i class="bi bi-circle"></i><span>Tabel Cluster</span>
          </a>
        </li>
        <li>
          <a href="grafik_cluster.php" class="<?= $current == 'grafik_cluster.php' ? 'active' : '' ?>">
            <i class="bi bi-circle"></i><span>Grafik Cluster</span>
          </a>
        </li>
      </ul>
    </li>

    <!-- Tambahan menu baru -->
    <li class="nav-item">
      <a class="nav-link <?= $current == 'users.php' ? '' : 'collapsed' ?>" href="users.php">
        <i class="bi bi-person-lines-fill"></i><span>Data Pelapor</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?= $current == 'dusun.php' ? '' : 'collapsed' ?>" href="dusun.php">
        <i class="bi bi-house-door"></i><span>Data Dusun</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link <?= $current == 'kategori.php' ? '' : 'collapsed' ?>" href="kategori.php">
        <i class="bi bi-tags"></i><span>Data Kategori</span>
      </a>
    </li>
    <!-- End tambahan menu -->

    <li class="nav-item">
      <a class="nav-link <?= $current == 'laporan.php' ? '' : 'collapsed' ?>" href="laporan.php">
        <i class="bi bi-file-earmark-bar-graph"></i><span>Laporan</span>
      </a>
    </li>

  </ul>
</aside><!-- End Sidebar -->

<main id="main" class="main">
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  document.getElementById('logoutBtn')?.addEventListener('click', function (e) {
    e.preventDefault();
    Swal.fire({
      title: 'Yakin ingin Logout?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#aaa',
      confirmButtonText: 'Ya, Logout',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = 'logout.php';
      }
    });
  });
</script>
