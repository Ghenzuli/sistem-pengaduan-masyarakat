<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
include 'partials/sidebar.php';

// ===============================
// AMBIL DATA DARI TABEL HASIL_CLUSTER
// ===============================

$query = mysqli_query($conn, "
  SELECT hc.*, d.nama_dusun, k.nama_kategori
  FROM hasil_cluster hc
  JOIN dusun d ON hc.dusun_id = d.id_dusun
  JOIN kategori k ON hc.kategori_id = k.id_kategori
  ORDER BY jumlah_pengaduan DESC
");
?>

<div class="pagetitle">
  <h1>Hasil Clustering</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item active">Cluster Berdasarkan Dusun & Kategori</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="card">
    <div class="card-body pt-3">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="card-title mb-0">Rekap Pengaduan Terbanyak</h5>
        <a href="proses_cluster.php" class="btn btn-sm btn-outline-primary">
          <i class="bi bi-arrow-repeat"></i> Proses Ulang
        </a>
      </div>

      <div class="table-responsive">
        <table id="tabelCluster" class="table table-striped">
          <thead>
            <tr>
              <th>No</th>
              <th>Dusun</th>
              <th>Kategori</th>
              <th>Jumlah Pengaduan</th>
              <?php if (mysqli_num_rows($query) && mysqli_field_seek($query, 0)) {
                $field = mysqli_fetch_field_direct($query, 4);
                if ($field && $field->name === 'cluster_ke') {
                  echo "<th>Cluster Ke</th>";
                }
              } ?>
            </tr>
          </thead>
          <tbody>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($query)) : ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_dusun']) ?></td>
                <td><?= htmlspecialchars($row['nama_kategori']) ?></td>
                <td><span class="badge bg-success"><?= $row['jumlah_pengaduan'] ?></span></td>
                <?php if (isset($row['cluster_ke'])): ?>
                  <td><span class="badge bg-primary">Cluster <?= $row['cluster_ke'] ?></span></td>
                <?php endif; ?>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
<hr class="my-4">
<h5 class="card-title">Rekomendasi Berdasarkan Cluster</h5>

<?php
// Ambil ulang data hasil cluster karena $query sudah habis dibaca di atas
$query_rekomendasi = mysqli_query($conn, "
  SELECT hc.*, d.nama_dusun, k.nama_kategori 
  FROM hasil_cluster hc
  JOIN dusun d ON hc.dusun_id = d.id_dusun
  JOIN kategori k ON hc.kategori_id = k.id_kategori
  ORDER BY cluster_ke, jumlah_pengaduan DESC
");

$cluster_data = [];

while ($row = mysqli_fetch_assoc($query_rekomendasi)) {
  $cluster = $row['cluster_ke'];
  $cluster_data[$cluster][] = $row;
}
function buatKalimatRekomendasi($dusun, $kategori, $jumlah) {
  $template = [
    "Dusun $dusun mencatat $jumlah pengaduan terkait $kategori. Perlu perhatian khusus dari pihak desa.",
    "Jumlah pengaduan sebanyak $jumlah dari Dusun $dusun menunjukkan permasalahan dalam bidang $kategori.",
    "Desa disarankan memprioritaskan penanganan kategori $kategori di Dusun $dusun.",
    "Kategori $kategori menjadi perhatian utama di Dusun $dusun dengan $jumlah pengaduan.",
    "Dusun $dusun menonjol dengan $jumlah pengaduan dalam bidang $kategori. Tindak lanjut dibutuhkan.",
    "Berdasarkan $jumlah pengaduan, Dusun $dusun membutuhkan penanganan segera di bidang $kategori.",
    "Dusun $dusun mengalami masalah dominan pada kategori $kategori, dengan $jumlah aduan yang masuk.",
    "$jumlah pengaduan tercatat dari Dusun $dusun dalam kategori $kategori. Prioritas penanganan disarankan.",
    "Permasalahan terkait $kategori cukup tinggi di Dusun $dusun. Tercatat $jumlah laporan dari warga.",
    "Dusun $dusun menjadi salah satu wilayah dengan pengaduan tertinggi terkait $kategori, yakni $jumlah kasus.",
    "Warga Dusun $dusun banyak melaporkan isu seputar $kategori sebanyak $jumlah laporan.",
    "Tingginya laporan dari Dusun $dusun tentang $kategori ($jumlah laporan) memerlukan perhatian serius.",
    "Jumlah laporan sebanyak $jumlah di bidang $kategori menunjukkan urgensi di Dusun $dusun.",
    "Dusun $dusun patut menjadi perhatian untuk isu $kategori, setelah tercatat $jumlah pengaduan.",
    "Pemerintah desa dapat memprioritaskan Dusun $dusun dalam penanganan isu $kategori.",
    "Kategori $kategori dominan dilaporkan dari Dusun $dusun sejumlah $jumlah kasus.",
    "Warga Dusun $dusun mengeluhkan permasalahan $kategori dalam $jumlah laporan.",
    "Masalah $kategori mendominasi aduan dari Dusun $dusun dengan $jumlah laporan.",
    "Dengan $jumlah laporan kategori $kategori, Dusun $dusun perlu menjadi fokus perbaikan.",
    "Tingginya aduan dari Dusun $dusun pada kategori $kategori perlu ditindaklanjuti segera.",
    "Prioritaskan Dusun $dusun untuk pembenahan di sektor $kategori, dengan $jumlah pengaduan tercatat.",
    "Dusun $dusun menunjukkan urgensi dalam hal $kategori, dengan $jumlah aduan dari masyarakat.",
    "Isu $kategori di Dusun $dusun menjadi perhatian dengan $jumlah laporan pengaduan.",
    "Peningkatan pengaduan dari Dusun $dusun terkait $kategori ($jumlah laporan) menunjukkan perlunya evaluasi.",
    "Dengan banyaknya laporan ($jumlah) di Dusun $dusun, kategori $kategori butuh respon cepat.",
    "Dusun $dusun memiliki tantangan di bidang $kategori dengan $jumlah laporan yang masuk.",
    "Meningkatnya laporan di Dusun $dusun soal $kategori mencerminkan kebutuhan penanganan segera.",
    "Desa perlu mengambil tindakan strategis atas laporan $kategori dari Dusun $dusun ($jumlah laporan).",
    "Dusun $dusun menghadapi permasalahan $kategori yang signifikan berdasarkan $jumlah laporan.",
    "Tingkat pengaduan tinggi di Dusun $dusun mengenai $kategori menunjukkan perlunya program khusus.",
    "Dusun $dusun teridentifikasi memiliki keluhan terbanyak di bidang $kategori sejumlah $jumlah laporan.",
    "Dengan $jumlah pengaduan, Dusun $dusun menjadi prioritas untuk penyelesaian masalah $kategori.",
    "Kategori $kategori di Dusun $dusun menjadi fokus utama dengan adanya $jumlah laporan warga.",
    "Desa perlu merespons laporan $kategori yang tinggi di Dusun $dusun sebanyak $jumlah pengaduan.",
    "Masukan masyarakat Dusun $dusun terhadap $kategori sudah mencapai $jumlah laporan dan harus ditindaklanjuti.",
    "Pemerintah desa sebaiknya memulai intervensi di Dusun $dusun dalam hal $kategori, mengingat $jumlah laporan masuk.",
    "Pengaduan dari Dusun $dusun terkait $kategori mendominasi sejumlah $jumlah kasus.",
    "Dusun $dusun menempati posisi teratas dalam jumlah pengaduan $kategori ($jumlah kasus).",
    "Jumlah laporan dari Dusun $dusun menunjukkan adanya masalah $kategori yang belum terselesaikan.",
    "Prioritas pembangunan perlu diarahkan ke Dusun $dusun pada bidang $kategori dengan $jumlah laporan.",
    "Kondisi di Dusun $dusun membutuhkan perhatian ekstra terhadap masalah $kategori ($jumlah aduan).",
    "Dusun $dusun memperlihatkan tingkat ketidakpuasan tertinggi terhadap $kategori.",
    "Permintaan penyelesaian isu $kategori di Dusun $dusun meningkat berdasarkan $jumlah pengaduan.",
    "Banyaknya aduan dari Dusun $dusun pada $kategori menunjukkan isu serius yang perlu ditindaklanjuti.",
    "Dusun $dusun menjadi fokus utama dalam hal $kategori dengan $jumlah pengaduan dari warganya.",
    "Masalah $kategori mendesak ditangani di Dusun $dusun yang mencatat $jumlah laporan.",
    "Aduan yang tinggi tentang $kategori dari Dusun $dusun ($jumlah laporan) menjadi dasar perlunya evaluasi.",
    "Desa dapat merancang program pembenahan $kategori khusus untuk Dusun $dusun.",
    "Dari $jumlah laporan, Dusun $dusun patut diprioritaskan dalam penanganan masalah $kategori.",
    "Data menunjukkan Dusun $dusun sebagai wilayah dengan konsentrasi pengaduan $kategori tertinggi."
  ];

  return $template[array_rand($template)];
}

foreach ($cluster_data as $cluster_ke => $data_cluster) {
  echo "<div class='card mb-3 border-start border-4 border-primary'>";
  echo "<div class='card-body'>";
  echo "<h6 class='text-primary fw-bold'>Cluster $cluster_ke</h6><ul class='mb-0'>";
  
  foreach ($data_cluster as $item) {
    $dusun = htmlspecialchars($item['nama_dusun']);
    $kategori = htmlspecialchars($item['nama_kategori']);
    $jumlah = $item['jumlah_pengaduan'];

    echo "<li>" . buatKalimatRekomendasi($dusun, $kategori, $jumlah) . "</li>";
  }

  echo "</ul></div></div>";
}
?>

    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const table = document.querySelector("#tabelCluster");
  if (table) {
    new simpleDatatables.DataTable(table, {
      labels: {
        placeholder: "Cari...",
        perPage: "entri per halaman",
        noRows: "Tidak ada data ditemukan",
        info: "Menampilkan {start} - {end} dari total {rows} entri"
      },
      layout: {
        top: "{select}",
        bottom: "{info}{pager}"
      }
    });
  }
});
</script>
