<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
include 'partials/sidebar.php';

// Tambah dusun
if (isset($_POST['tambah'])) {
  $nama = $_POST['nama_dusun'];
  $stmt = $conn->prepare("INSERT INTO dusun (nama_dusun) VALUES (?)");
  $stmt->bind_param("s", $nama);
  $stmt->execute();
  header("Location: dusun.php");
}

// Edit dusun
if (isset($_POST['edit'])) {
  $id = $_POST['id_dusun'];
  $nama = $_POST['nama_dusun'];
  $stmt = $conn->prepare("UPDATE dusun SET nama_dusun=? WHERE id_dusun=?");
  $stmt->bind_param("si", $nama, $id);
  $stmt->execute();
  header("Location: dusun.php");
}

// Hapus dusun
if (isset($_GET['hapus'])) {
  $id = $_GET['hapus'];
  $conn->query("DELETE FROM dusun WHERE id_dusun=$id");
  header("Location: dusun.php");
}

// Ambil data dusun
$query = mysqli_query($conn, "SELECT * FROM dusun ORDER BY id_dusun ASC");
?>

<div class="pagetitle">
  <h1>Data Dusun</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item active">Dusun</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="card">
    <div class="card-body pt-3">
      <h5 class="card-title">Daftar Dusun</h5>

      <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalTambah">Tambah Dusun</button>

      <div class="table-responsive">
        <table id="tabelDusun" class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Dusun</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1; 
            $modals = '';
            while ($row = mysqli_fetch_assoc($query)) : ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama_dusun']) ?></td>
                <td>
                  <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id_dusun'] ?>">Edit</button>
                  <a href="dusun.php?hapus=<?= $row['id_dusun'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
              </tr>
              <?php
              $modals .= '
              <div class="modal fade" id="modalEdit' . $row['id_dusun'] . '" tabindex="-1">
                <div class="modal-dialog">
                  <form method="post" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit Dusun</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                      <input type="hidden" name="id_dusun" value="' . $row['id_dusun'] . '">
                      <div class="mb-3">
                        <label class="form-label">Nama Dusun</label>
                        <input type="text" name="nama_dusun" class="form-control" value="' . htmlspecialchars($row['nama_dusun']) . '" required>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                    </div>
                  </form>
                </div>
              </div>';
              ?>
            <?php endwhile; ?>
          </tbody>
        </table>
        <?= $modals ?>
      </div>

    </div>
  </div>
</section>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Dusun</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">Nama Dusun</label>
          <input type="text" name="nama_dusun" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah" class="btn btn-success">Tambah</button>
      </div>
    </form>
  </div>
</div>

<?php include 'partials/footer.php'; ?>

<!-- DataTables -->
<script>
document.addEventListener("DOMContentLoaded", () => {
  const tabelDusun = document.querySelector("#tabelDusun");
  if (tabelDusun) {
    new simpleDatatables.DataTable(tabelDusun, {
      labels: {
        placeholder: "Cari...",
        perPage: "entri per halaman",
        noRows: "Tidak ada data ditemukan",
        info: "Menampilkan {start} - {end} dari total {rows} entri"
      },
      layout: {
        top: "{select}",
        bottom: "{info}{pager}"
      }
    });
  }
});
</script>
