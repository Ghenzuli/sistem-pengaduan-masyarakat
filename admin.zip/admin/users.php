<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  header("Location: login.php");
  exit;
}

include '../config/koneksi.php';
include 'partials/sidebar.php';

// Tambah pelapor
if (isset($_POST['tambah'])) {
  $nik = $_POST['nik'];
  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $password = md5($_POST['password']);
  $no_hp = $_POST['no_hp'];
  $dusun = $_POST['dusun'];

  if (strlen($nik) != 16) {
    $_SESSION['error'] = "NIK harus 16 digit.";
  } elseif (empty($email)) {
    $_SESSION['error'] = "Email tidak boleh kosong.";
  } else {
    $stmt = $conn->prepare("INSERT INTO users (nik, nama, email, password, no_hp, dusun) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssis", $nik, $nama, $email, $password, $no_hp, $dusun);
    $stmt->execute();
    $_SESSION['success'] = "Pelapor berhasil ditambahkan.";
  }
  header("Location: users.php");
  exit;
}

// Edit pelapor
if (isset($_POST['edit'])) {
  $nik = $_POST['nik'];
  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $no_hp = $_POST['no_hp'];
  $dusun = $_POST['dusun'];

  if (strlen($nik) != 16) {
    $_SESSION['error_edit'] = "NIK harus 16 digit.";
    $_SESSION['nik_edit_gagal'] = $nik;
  } elseif (empty($email)) {
    $_SESSION['error_edit'] = "Email tidak boleh kosong.";
    $_SESSION['nik_edit_gagal'] = $nik;
  } else {
    $stmt = $conn->prepare("UPDATE users SET nama=?, email=?, no_hp=?, dusun=? WHERE nik=?");
    $stmt->bind_param("ssisi", $nama, $email, $no_hp, $dusun, $nik);
    $stmt->execute();
    $_SESSION['success'] = "Data pelapor berhasil diperbarui.";
  }
  header("Location: users.php");
  exit;
}

// Ambil data
$query = mysqli_query($conn, "SELECT * FROM users ORDER BY nama ASC");
?>

<div class="pagetitle">
  <h1>Data Pelapor</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
      <li class="breadcrumb-item active">Pelapor</li>
    </ol>
  </nav>
</div>

<section class="section">
  <div class="card">
    <div class="card-body pt-3">
      <h5 class="card-title">Daftar Warga Pelapor</h5>

      <?php if (isset($_SESSION['error'])) : ?>
        <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
      <?php elseif (isset($_SESSION['success'])) : ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
      <?php endif; ?>

      <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalTambah">Tambah Pelapor</button>

      <div class="table-responsive">
        <table id="tabelUsers" class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>NIK</th>
              <th>Nama</th>
              <th>Email</th>
              <th>No HP</th>
              <th>Dusun</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1; 
            $modals = '';
            while ($row = mysqli_fetch_assoc($query)) :
            ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= $row['nik'] ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= $row['email'] ?></td>
                <td><?= $row['no_hp'] ?></td>
                <td><?= htmlspecialchars($row['dusun']) ?></td>
                <td>
                  <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['nik'] ?>">Detail</button>
                </td>
              </tr>

              <?php
              // Modal Detail & Edit
              $modals .= '
              <!-- Modal Detail -->
              <div class="modal fade" id="modalDetail' . $row['nik'] . '" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Detail Pelapor</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                      <p><strong>NIK:</strong> ' . $row['nik'] . '</p>
                      <p><strong>Nama:</strong> ' . htmlspecialchars($row['nama']) . '</p>
                      <p><strong>Email:</strong> ' . $row['email'] . '</p>
                      <p><strong>No HP:</strong> ' . $row['no_hp'] . '</p>
                      <p><strong>Dusun:</strong> ' . htmlspecialchars($row['dusun']) . '</p>
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-warning" data-bs-target="#modalEdit' . $row['nik'] . '" data-bs-toggle="modal" data-bs-dismiss="modal">Edit</button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Modal Edit -->
              <div class="modal fade" id="modalEdit' . $row['nik'] . '" tabindex="-1">
                <div class="modal-dialog">
                  <form method="post" class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Edit Pelapor</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">';

              if (isset($_SESSION['error_edit']) && $_SESSION['nik_edit_gagal'] == $row['nik']) {
                $modals .= '<div class="alert alert-danger">' . $_SESSION['error_edit'] . '</div>';
              }

              $modals .= '
                      <input type="hidden" name="nik" value="' . $row['nik'] . '">
                      <div class="mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="nama" class="form-control" value="' . htmlspecialchars($row['nama']) . '" required>
                      </div>
                      <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" value="' . $row['email'] . '" required>
                      </div>
                      <div class="mb-3">
                        <label class="form-label">No HP</label>
                        <input type="number" name="no_hp" class="form-control" value="' . $row['no_hp'] . '">
                      </div>
                      <div class="mb-3">
                        <label class="form-label">Dusun</label>
                        <input type="text" name="dusun" class="form-control" value="' . htmlspecialchars($row['dusun']) . '" required>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" name="edit" class="btn btn-primary">Simpan</button>
                    </div>
                  </form>
                </div>
              </div>';
              ?>
            <?php endwhile; ?>
          </tbody>
        </table>
        <?= $modals ?>
        <?php unset($_SESSION['error_edit'], $_SESSION['nik_edit_gagal']); ?>
      </div>
    </div>
  </div>
</section>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Tambah Pelapor</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label">NIK</label>
          <input type="number" name="nik" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Nama</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">No HP</label>
          <input type="number" name="no_hp" class="form-control">
        </div>
        <div class="mb-3">
          <label class="form-label">Dusun</label>
          <input type="text" name="dusun" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah" class="btn btn-success">Tambah</button>
      </div>
    </form>
  </div>
</div>

<?php include 'partials/footer.php'; ?>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const table = document.querySelector("#tabelUsers");
  if (table) {
    new simpleDatatables.DataTable(table, {
      labels: {
        placeholder: "Cari...",
        perPage: "entri per halaman",
        noRows: "Tidak ada data ditemukan",
        info: "Menampilkan {start} - {end} dari total {rows} entri"
      },
      layout: {
        top: "{select}",
        bottom: "{info}{pager}"
      }
    });
  }

  <?php if (isset($_SESSION['nik_edit_gagal'])) : ?>
    const failedEditModal = new bootstrap.Modal(document.getElementById("modalEdit<?= $_SESSION['nik_edit_gagal'] ?>"));
    failedEditModal.show();
  <?php endif; ?>
});
</script>
