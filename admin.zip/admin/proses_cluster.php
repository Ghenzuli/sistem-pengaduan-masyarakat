<?php
include '../config/koneksi.php';

// Debug error tampil
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ===== Fungsi Jarak Euclidean =====
function hitung_jarak($v1, $v2) {
  $jarak = 0;
  for ($i = 0; $i < count($v1); $i++) {
    $jarak += pow($v1[$i] - $v2[$i], 2);
  }
  return sqrt($jarak);
}

// ===== Fungsi Level Kemiripan Berdasarkan Jarak =====
function levelKemiripan($jarak) {
  if ($jarak < 2) return "Sangat Mirip";
  elseif ($jarak < 4) return "Cukup Mirip";
  else return "Tidak Mirip";
}

// ===== Langkah 1: Ambil vektor jumlah pengaduan per dusun per kategori =====
$query = mysqli_query($conn, "
  SELECT 
    d.nama_dusun,
    SUM(IF(p.kategori_id = 1, 1, 0)) AS Infrastruktur,
    SUM(IF(p.kategori_id = 2, 1, 0)) AS Kebersihan,
    SUM(IF(p.kategori_id = 3, 1, 0)) AS Keamanan,
    SUM(IF(p.kategori_id = 4, 1, 0)) AS Sosial,
    SUM(IF(p.kategori_id = 5, 1, 0)) AS Administrasi
  FROM pengaduan p
  JOIN dusun d ON p.dusun_id = d.id_dusun
  GROUP BY p.dusun_id
");

// Bentuk array data vektor
$data_vektor = [];
while ($row = mysqli_fetch_assoc($query)) {
  $data_vektor[] = [
    'nama_dusun' => $row['nama_dusun'],
    'vektor' => [
      (int)$row['Infrastruktur'],
      (int)$row['Kebersihan'],
      (int)$row['Keamanan'],
      (int)$row['Sosial'],
      (int)$row['Administrasi']
    ]
  ];
}

// ===== Langkah 2: Tentukan centroid awal secara acak =====
$jumlah_cluster = 6;
shuffle($data_vektor);
$centroids = array_slice($data_vektor, 0, $jumlah_cluster);

// ===== Iterasi K-Means =====
$assignments = [];
$max_iterasi = 100;
$iterasi = 0;
$berubah = true;

while ($berubah && $iterasi < $max_iterasi) {
  $iterasi++;
  $berubah = false;

  $new_assignments = [];
  foreach ($data_vektor as $dusun) {
    $jarak_terdekat = null;
    $cluster_terdekat = null;

    foreach ($centroids as $index => $centroid) {
      $jarak = hitung_jarak($dusun['vektor'], $centroid['vektor']);
      if ($jarak_terdekat === null || $jarak < $jarak_terdekat) {
        $jarak_terdekat = $jarak;
        $cluster_terdekat = $index;
      }
    }

    // Tampilkan alasan kenapa masuk cluster ini
    $nama_dusun = $dusun['nama_dusun'];
    $tingkat = levelKemiripan($jarak_terdekat);
    echo "<p style='font-family:monospace;'>
      Dusun <b>$nama_dusun</b> masuk ke <b>Cluster $cluster_terdekat</b> 
      karena jaraknya ke centroid = <b>" . round($jarak_terdekat, 3) . "</b> 
      ➜ <i>$tingkat</i>.
    </p>";

    $new_assignments[] = [
      'nama_dusun' => $dusun['nama_dusun'],
      'vektor' => $dusun['vektor'],
      'cluster' => $cluster_terdekat
    ];
  }

  if ($assignments !== $new_assignments) {
    $berubah = true;
  }

  $assignments = $new_assignments;

  // Hitung centroid baru
  $centroids = [];
  foreach ($assignments as $item) {
    $c = $item['cluster'];
    if (!isset($centroids[$c])) {
      $centroids[$c] = [
        'nama_dusun' => "Centroid $c",
        'count' => 0,
        'sum' => array_fill(0, count($item['vektor']), 0)
      ];
    }
    foreach ($item['vektor'] as $i => $val) {
      $centroids[$c]['sum'][$i] += $val;
    }
    $centroids[$c]['count']++;
  }

  foreach ($centroids as $cluster => $centroid) {
    $centroids[$cluster] = [
      'nama_dusun' => "Centroid $cluster",
      'vektor' => array_map(function ($val) use ($centroid) {
        return $centroid['count'] > 0 ? $val / $centroid['count'] : 0;
      }, $centroid['sum'])
    ];
  }
}

// ===== Langkah 6: Simpan hasil ke tabel hasil_cluster =====
mysqli_query($conn, "TRUNCATE TABLE hasil_cluster");

foreach ($assignments as $item) {
  $nama_dusun = mysqli_real_escape_string($conn, $item['nama_dusun']);
  $dusun_q = mysqli_query($conn, "SELECT id_dusun FROM dusun WHERE nama_dusun = '$nama_dusun'");
  $dusun_row = mysqli_fetch_assoc($dusun_q);
  if (!$dusun_row) continue; // Lewati jika tidak ditemukan
  $dusun_id = $dusun_row['id_dusun'];

  $kategori_ids = [1, 2, 3, 4, 5];
  foreach ($kategori_ids as $i => $kategori_id) {
    $jumlah = $item['vektor'][$i];
    if ($jumlah > 0) {
      mysqli_query($conn, "
        INSERT INTO hasil_cluster (dusun_id, kategori_id, jumlah_pengaduan, cluster_ke)
        VALUES ($dusun_id, $kategori_id, $jumlah, {$item['cluster']})
      ");
    }
  }
}

// ===== Tampilan akhir =====
echo "<p style='font-family:monospace; color:green;'>✓ Data hasil_cluster berhasil disimpan setelah $iterasi iterasi.</p>";
echo "<a href='cluster.php'>Lihat Hasil</a>";
?>
