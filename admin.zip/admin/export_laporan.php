<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
  exit('Unauthorized');
}

require_once '../vendor/autoload.php';   // path composer
include '../config/koneksi.php';

use Dompdf\Dompdf;
use Dompdf\Options;

/* ── Ambil parameter tanggal ─────────────────────────────── */
$dari   = !empty($_GET['dari'])   ? $_GET['dari']   : '';
$sampai = !empty($_GET['sampai']) ? $_GET['sampai'] : '';

$where  = ($dari && $sampai)
          ? "WHERE p.tanggal BETWEEN '$dari' AND '$sampai'"
          : '';

/* ── Query data (JOIN users utk nama) ────────────────────── */
$sql = "
  SELECT p.*, u.nama AS nama_pelapor, k.nama_kategori, d.nama_dusun
  FROM pengaduan p
  JOIN users    u ON p.nik         = u.nik
  JOIN kategori k ON p.kategori_id = k.id_kategori
  JOIN dusun    d ON p.dusun_id    = d.id_dusun
  $where
  ORDER BY p.tanggal DESC
";
$result = mysqli_query($conn, $sql);

/* ── HTML + CSS untuk PDF ───────────────────────────────── */
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Laporan Pengaduan</title>
  <style>
    body  { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    h2    { text-align: center; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; }
    th, td {
      border: 1px solid #000; padding: 5px 8px; text-align: left;
      vertical-align: top; word-wrap: break-word;
    }
    th      { background: #eaeaea; }
    .badge  { padding: 2px 5px; border-radius: 4px; color:#fff; font-size:10px; }
    .success   { background:#28a745; }
    .warning   { background:#ffc107; color:#000; }
    .secondary { background:#6c757d; }
  </style>
</head>
<body>
  <h2 style="margin-bottom:5px;">Laporan Pengaduan</h2>
  <?php if ($dari && $sampai): ?>
    <p style="text-align:center; font-size:12px; margin-top:0;">
      Periode <?= date('d/m/Y', strtotime($dari)) ?> - <?= date('d/m/Y', strtotime($sampai)) ?>
    </p>
  <?php endif; ?>

  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Pelapor</th>
        <th>Dusun</th>
        <th>Kategori</th>
        <th>Isi</th>
        <th>Tanggal</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?= $no++ ?></td>
          <td><?= htmlspecialchars($row['nama_pelapor']) ?></td>
          <td><?= $row['nama_dusun'] ?></td>
          <td><?= $row['nama_kategori'] ?></td>
          <td><?= htmlspecialchars($row['isi_pengaduan']) ?></td>
          <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
          <td>
            <span class="badge <?= $row['status']=='Selesai'?'success':($row['status']=='Diproses'?'warning':'secondary') ?>">
              <?= $row['status'] ?>
            </span>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
<?php
$html = ob_get_clean();

/* ── Render PDF dengan Dompdf ───────────────────────────── */
$options = new Options;
$options->set('isRemoteEnabled', true);   // jika load img/css eksternal
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$filename = 'laporan_pengaduan_' . date('Ymd_His') . '.pdf';
$dompdf->stream($filename, ['Attachment' => true]);
exit;